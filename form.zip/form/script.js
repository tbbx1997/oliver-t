// var type = document.getElementById("types").value;
// var label = document.getElementById("txt-lb").value;
// var name = document.getElementById("name").value;
// var _id = document.getElementById("_id").value;
// var _placehoder = document.getElementById("_placehoder").value;
// var _require = document.getElementById("_require").value;
// var data = [];
// data.push({
//     type: type,
//     label: label,
//     name: name,
//     _id: _id,
//     _placehoder: _placehoder,
//     _require: _require
// });
// listdata.push(data);
// localStorage.setItem('data', JSON.stringify(listdata));